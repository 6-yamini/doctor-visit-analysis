# Doctor_visit_analysis
Doctor visit analysis is a data analysis project whcih is assigned during my internship from TASK and IBM during May - July 2023 as data analyst role.

Python IDE: Jupyter Notebook

Libraries: pandas, seaborn, matplotlib, numpy

#Project description

Analyzing patients records by exploring data, summarizing it and visualize it for gaining effective insights on patients records.
